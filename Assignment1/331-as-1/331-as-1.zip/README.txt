README
CMPUT 331 Assignment 1: Christopher Pontikes 1499276
Resources consulted includes ceaserCipher.py provided by the instructors. Some
sections of code were copied from that program and used in a1p1.py, a1p2.py and a1p3.py
